package com.example.plantcare

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class CalenderActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calender)
    }
}