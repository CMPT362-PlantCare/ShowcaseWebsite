package com.example.plantcare

class WateringEventEntry {
    var plantName: String = ""
}
