PlantCare App Citations:

The design for the Login & Signup pages adapted from this youtube video: https://www.youtube.com/watch?v=idbxxkF1l6k