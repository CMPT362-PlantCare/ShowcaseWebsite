# PlantCare
Android Plant Care Application
